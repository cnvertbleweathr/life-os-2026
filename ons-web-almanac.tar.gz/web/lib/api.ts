/**
 * lib/api.ts — typed client for the ONS FastAPI backend.
 *
 * Every type here reflects the CONFIRMED response shapes from
 * API_STATE_REFERENCE.md (verified 2026-06-19 against live data).
 * Types added for the Almanac UI revamp (2026-06-21) are marked.
 */

const API_BASE =
  process.env.NEXT_PUBLIC_API_BASE ?? "http://localhost:8000/api";

async function get<T>(path: string): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, { cache: "no-store" });
  if (!res.ok) {
    throw new Error(`API ${path} returned ${res.status}`);
  }
  return res.json();
}

// ── Shared / cross-cutting types ──────────────────────────────────────────────

export interface Goal {
  domain: string;
  goal_key: string;
  goal_value_type: string;
  target_numeric: number | null;
  current_value: number | null;
  progress_percent: number | null;
  pace_status?: string | null;
  label: string;
  description?: string | null;
}

// ── Home ─────────────────────────────────────────────────────────────────────

export interface HomeSummary {
  date: string;
  stat_cards: {
    weekly_miles: number;
    weekly_runs: number;
    ytd_miles: number;
    habits_done: number;
    habits_total: number;
    books_read: number;
  };
  calendar: { date: string; title: string }[];
  wod: {
    date: string;
    url: string;
    text: string;
    movements: string[];
    fetched_ok: boolean;
  } | null;
  daily10: {
    date: string;
    playlist_id: string;
    updated_at_utc: string;
    description: string;
    tewnidge_artists: string[];
  } | null;
  picks: unknown[];
  goals: Goal[];
  streams: {
    fetched_at: string;
    my_teams: unknown[];
    top5: unknown[];
    popular: unknown[];
  } | null;
}

export interface CalendarEvent {
  date: string;
  title: string;
}

export const homeApi = {
  summary: () => get<HomeSummary>("/home/summary"),
  calendar: () => get<CalendarEvent[]>("/home/calendar"),
};

// ── Habits ───────────────────────────────────────────────────────────────────

/** Almanac revision: flattened habit item for the new Habits page */
export interface HabitItem {
  key: string;
  label: string;
  done: boolean;
}

export interface HabitToday {
  date: string;
  habits: HabitItem[];
  done_count: number;
  total_count: number;
}

export interface HabitStreak {
  habit: string;
  current_streak: number;
  longest_streak: number;
}

export const habitsApi = {
  today: () => get<HabitToday>("/habits/today"),
  streaks: () => get<HabitStreak[]>("/habits/streaks"),
};

// ── Fitness ──────────────────────────────────────────────────────────────────

export interface FitnessSummary {
  running_summary: {
    total_miles: number;
    total_runs: number;
    avg_pace_min_mile: number;
    ytd_miles: number;
  };
  recent_runs: {
    run_date: string;
    miles: number;
    minutes: number;
    pace: number;
  }[];
  weekly_miles: { week: string; miles: number }[];
}

export const fitnessApi = {
  summary: () => get<FitnessSummary>("/fitness/summary"),
};

// ── Reading ──────────────────────────────────────────────────────────────────

export interface ReadingSummary {
  books_read: number;
  fiction_books: number;
  nonfiction_books: number;
}

export const readingApi = {
  summary: () => get<ReadingSummary>("/reading/summary"),
  inProgress: () => get<unknown[]>("/reading/in-progress"),
};

// ── Goals ────────────────────────────────────────────────────────────────────

export interface GoalDomainGroup {
  domain: string;
  goals: Goal[];
}

export const goalsApi = {
  progress: () => get<Goal[]>("/goals/progress"),
  byDomain: () => get<GoalDomainGroup[]>("/goals/by-domain"),
};

// ── Music ────────────────────────────────────────────────────────────────────

/** Almanac revision: combined summary type for the Music page.
 *  Built client-side from the existing separate endpoints. */
export interface MusicSummary {
  top_artists: Array<{ name: string; plays?: number; minutes?: number; hours?: number }>;
  listening_hours: number;
  streams_ytd: number;
}

export const musicApi = {
  topArtists: () => get<unknown[]>("/music/top-artists"),
  news: () => get<unknown[]>("/music/news"),
  /** Convenience wrapper that assembles MusicSummary from existing endpoints */
  summary: async (): Promise<MusicSummary> => {
    const artists = await get<any[]>("/music/top-artists");
    return {
      top_artists: artists ?? [],
      listening_hours: 0,
      streams_ytd: 0,
    };
  },
};

// ── Shows ────────────────────────────────────────────────────────────────────

export interface ShowsSummary {
  total: number;
  my_artist_count: number;
  venues: number;
  next_show: { title: string; date: string; venue: string } | null;
}

export interface Show {
  title: string;
  venue_name: string;
  ticket_url: string;
  source: "AEG" | "Ticketmaster";
  is_my_artist: boolean;
  date: string;
  // Almanac aliases for easier use in the new pages
  venue?: string;   // alias for venue_name, populated by the wrapper
}

export const showsApi = {
  summary: async (): Promise<ShowsSummary & {
    total_shows: number;
    venue_count: number;
  }> => {
    const s = await get<ShowsSummary>("/shows/summary");
    return {
      ...s,
      total_shows: s.total,
      venue_count: s.venues,
    };
  },
  list: async (myArtistsOnly = false): Promise<Show[]> => {
    const shows = await get<Show[]>(
      `/shows${myArtistsOnly ? "?my_artists_only=true" : ""}`
    );
    return shows.map((s) => ({ ...s, venue: s.venue_name }));
  },
  myShows: () => get<unknown[]>("/shows/my-shows"),
};

// ── Sports ───────────────────────────────────────────────────────────────────

export const sportsApi = {
  news: () => get<unknown[]>("/sports/news"),
};

// ── CFB ──────────────────────────────────────────────────────────────────────

export interface CfbTeam {
  team: string;
  tier: string;
  win_rate: number;
  roi_pct: number;
  seasons_profitable: number;
  total_bets: number;
  // Almanac aliases for the new profile panel — mapped from CfbTeamDetail
  power?: number;
  sr_edge?: number;
  returning_production?: number;
  pace?: number;
  coach_change?: boolean;
  profitable_seasons?: number;
  games?: number;
}

export interface CfbTeamDetail {
  profile: Record<string, unknown> & { season_rois_json?: string };
  recent_games: unknown[];
  advanced_stats: Record<string, unknown>;
}

export interface CfbRecruitingYear {
  season: number;
  weighted_talent: number;
  weighted_rank: number;
  talent_percentile: number;
  single_year_points: number;
  single_year_rank: number;
}

export const cfbApi = {
  teams: async (): Promise<CfbTeam[]> => {
    const teams = await get<CfbTeam[]>("/cfb/teams");
    // Map aliases so the Almanac profile panel can reference them
    return teams.map((t) => ({
      ...t,
      profitable_seasons: t.seasons_profitable,
      games: t.total_bets,
    }));
  },
  team: (team: string) =>
    get<CfbTeamDetail>(`/cfb/team/${encodeURIComponent(team)}`),
  gameContext: (gameId: string | number) =>
    get<Record<string, unknown>>(`/cfb/game-context/${gameId}`),
  recruiting: (team: string) =>
    get<CfbRecruitingYear[]>(`/cfb/recruiting/${encodeURIComponent(team)}`),
  modelInfo: () => get<Record<string, unknown>>("/cfb/model-info"),
  lineAccuracy: () => get<Record<string, unknown>[]>("/cfb/line-accuracy"),
};

export function parseSeasonRois(json?: string): Record<string, number> {
  if (!json) return {};
  try {
    return JSON.parse(json);
  } catch {
    return {};
  }
}

// ── KGLW ─────────────────────────────────────────────────────────────────────

export interface KglwShowTag {
  tag: string;
  tag_slug: string;
}

export interface KglwShow {
  show_id: number;
  show_date: string;
  show_time: string | null;
  artist: string;
  show_title: string;
  venue_id: number;
  venue_name: string;
  location: string;
  city: string;
  state: string | null;
  country: string;
  tour_name: string;
  show_year: number;
  show_month: number;
  show_day: number;
  show_dayname: string;
  show_tags: KglwShowTag[];
  permalink: string;
  // Almanac aliases mapped for the new explorer
  id?: number;
  date?: string;
  venue?: string;
  tour?: string;
  upcoming?: boolean;
  videoId?: string | null;
}

export interface KglwSong {
  song_id: number;
  name: string;
  slug: string;
  is_original: boolean;
  original_artist: string;
  // Almanac addition
  versions?: number;
}

export interface KglwVenue {
  venue_id: number;
  name: string;
  city: string;
  state: string | null;
  country: string;
  capacity: number | null;
  slug: string;
}

export interface KglwJamchartEntry {
  uniqueid: string;
  show_id: number;
  song_id: number;
  song_name: string;
  show_date: string;
  venue_name: string;
  city: string;
  state: string | null;
  country: string;
  footnote: string | null;
  jamchart_note: string | null;
  is_recommended: boolean;
  permalink: string;
}

export interface KglwSummary {
  total_shows: number;
  total_songs: number;
  total_venues: number;
  total_jamchart_entries: number;
  next_show: {
    show_date: string;
    venue_name: string;
    city: string;
    country: string;
    show_title: string;
  } | null;
}

export const kglwApi = {
  summary: () => get<KglwSummary>("/kglw/summary"),
  shows: async (
    opts?: { upcoming?: boolean; venueId?: number; limit?: number }
  ): Promise<KglwShow[]> => {
    const params = new URLSearchParams();
    if (opts?.upcoming) params.set("upcoming", "true");
    if (opts?.venueId != null) params.set("venue_id", String(opts.venueId));
    if (opts?.limit != null) params.set("limit", String(opts.limit));
    const qs = params.toString();
    const shows = await get<KglwShow[]>(`/kglw/shows${qs ? `?${qs}` : ""}`);
    // Map aliases for the Almanac explorer
    return shows.map((s) => ({
      ...s,
      id: s.show_id,
      date: s.show_date,
      venue: s.venue_name,
      tour: s.tour_name,
      upcoming: false, // no reliable upcoming flag from API
      videoId: null,    // no video data from API
    }));
  },
  show: (showId: number) => get<KglwShow | null>(`/kglw/shows/${showId}`),
  onThisDay: () => get<KglwShow[]>("/kglw/shows/on-this-day"),
  songs: async (search?: string): Promise<KglwSong[]> => {
    const songs = await get<KglwSong[]>(
      `/kglw/songs${search ? `?search=${encodeURIComponent(search)}` : ""}`
    );
    // versions isn't exposed — use 0 as placeholder
    return songs.map((s) => ({ ...s, versions: 0 }));
  },
  songShows: (songId: number) =>
    get<KglwJamchartEntry[]>(`/kglw/songs/${songId}/shows`),
  venues: (search?: string) =>
    get<KglwVenue[]>(
      `/kglw/venues${search ? `?search=${encodeURIComponent(search)}` : ""}`
    ),
  jamchart: (recommendedOnly = false) =>
    get<KglwJamchartEntry[]>(
      `/kglw/jamchart${recommendedOnly ? "?recommended=true" : ""}`
    ),
};
