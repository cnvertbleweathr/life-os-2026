"use client";

import { Card, PageHead, K, Empty } from "@/components/ui/primitives";
import { OnsIcon } from "@/components/ui/icons";

// Mock data for my teams — will wire to API when team-tracking source is exposed
const TEAMS = [
  {
    team: "Colorado Rockies", abbr: "COL", league: "MLB",
    standing: "NL West", record: "28–47", streak: "L2",
    form: ["L", "L", "W", "L", "L"],
    next: { opp: "vs MIA", date: "Jun 30", time: "6:40 PM" },
  },
  {
    team: "Denver Nuggets", abbr: "DEN", league: "NBA",
    standing: "WC #5", record: "50–32", streak: "—",
    form: ["W", "L", "W", "W", "L"],
    next: null,
  },
  {
    team: "Denver Broncos", abbr: "DEN", league: "NFL",
    standing: "AFC West", record: "10–7", streak: "—",
    form: ["W", "W", "L", "W", "W"],
    next: null,
  },
  {
    team: "Colorado Buffaloes", abbr: "CU", league: "CFB",
    standing: "Big 12", record: "9–4", streak: "—",
    form: [],
    next: null,
  },
];

const STREAMS = [
  { rank: 1, event: "Copa América: USA vs Colombia", league: "Soccer", time: "5:00 PM", viewers: "142k", hot: true, mine: false },
  { rank: 2, event: "NBA Draft Round 1", league: "NBA", time: "8:00 PM", viewers: "89k", hot: true, mine: true },
  { rank: 3, event: "College World Series Final", league: "NCAA", time: "7:00 PM", viewers: "64k", hot: false, mine: false },
  { rank: 4, event: "Rockies vs Marlins", league: "MLB", time: "6:40 PM", viewers: "12k", hot: false, mine: true },
  { rank: 5, event: "Wimbledon Qualifying", league: "Tennis", time: "6:00 AM", viewers: "31k", hot: false, mine: false },
];

export default function SportsPage() {
  return (
    <div className="ons-page" style={{ padding: "34px 44px 48px", maxWidth: 1380, margin: "0 auto" }}>
      <PageHead
        title="Sports"
        kicker="My teams · live streams via streamed.pk"
        right={
          <div className="font-mono text-right text-faint" style={{ fontSize: 9.5 }}>
            {TEAMS.length} TEAMS TRACKED<br />TOP 5 AI-RANKED
          </div>
        }
      />

      <div className="grid gap-[22px] items-start" style={{ gridTemplateColumns: "1fr 1fr" }}>
        {/* My Teams */}
        <div>
          <div className="mb-4" style={{ borderTop: "2.5px solid #1d5536", paddingTop: 12 }}>
            <K color="#232a22" style={{ fontSize: 11, letterSpacing: "1.5px" }}>My Teams</K>
          </div>
          <div className="flex flex-col gap-4">
            {TEAMS.map((t, i) => (
              <Card key={i}>
                <div className="flex items-center gap-3">
                  <div
                    className="grid place-items-center shrink-0 font-mono font-bold text-green"
                    style={{
                      width: 40, height: 40, borderRadius: 8,
                      background: "#e9efe7", border: "1px solid rgba(29,85,54,0.2)", fontSize: 13,
                    }}
                  >
                    {t.abbr}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-serif font-bold" style={{ fontSize: 17, lineHeight: 1.1 }}>{t.team}</div>
                    <div className="font-mono text-faint mt-[3px]" style={{ fontSize: 9.5 }}>
                      {t.league} · {t.standing}
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="font-serif font-bold" style={{ fontSize: 18 }}>{t.record}</div>
                    {t.streak !== "—" && (
                      <div
                        className="font-mono mt-0.5"
                        style={{ fontSize: 9, color: t.streak[0] === "W" ? "#1d5536" : "#a8473a" }}
                      >
                        {t.streak}
                      </div>
                    )}
                  </div>
                </div>
                {(t.form.length > 0 || t.next) && (
                  <div className="flex items-center gap-3 mt-[14px] pt-3 border-t border-border-2">
                    {t.form.length > 0 && (
                      <div className="flex gap-1">
                        {t.form.map((f, j) => (
                          <span
                            key={j}
                            className="grid place-items-center font-mono font-semibold"
                            style={{
                              width: 18, height: 18, borderRadius: 4, fontSize: 9,
                              color: "#fff",
                              background: f === "W" ? "#1d5536" : "#a8473a",
                              opacity: 0.55 + (j / t.form.length) * 0.45,
                            }}
                          >
                            {f}
                          </span>
                        ))}
                      </div>
                    )}
                    {t.next ? (
                      <div className="ml-auto text-right">
                        <span className="text-ink" style={{ fontSize: 12.5 }}>{t.next.opp}</span>
                        <span className="font-mono text-faint ml-2" style={{ fontSize: 9.5 }}>
                          {t.next.date} · {t.next.time}
                        </span>
                      </div>
                    ) : (
                      <span className="ml-auto font-mono text-faint" style={{ fontSize: 9.5 }}>
                        SEASON OVER
                      </span>
                    )}
                  </div>
                )}
              </Card>
            ))}
          </div>
        </div>

        {/* Live & Upcoming */}
        <div>
          <div
            className="flex justify-between items-center mb-4"
            style={{ borderTop: "2.5px solid #9a6a1e", paddingTop: 12 }}
          >
            <K color="#232a22" style={{ fontSize: 11, letterSpacing: "1.5px" }}>Live & Upcoming</K>
            <span className="font-mono text-faint" style={{ fontSize: 9 }}>streamed.pk · AI-ranked</span>
          </div>
          <Card pad={0} style={{ marginBottom: 22 }}>
            <div style={{ padding: "4px 18px 12px" }}>
              {STREAMS.map((s) => (
                <div
                  key={s.rank}
                  className="ons-row flex items-center gap-[13px] border-t border-border-2"
                  style={{ padding: "13px 6px", margin: "0 -6px" }}
                >
                  <span
                    className="font-serif font-bold"
                    style={{ fontSize: 17, color: s.rank === 1 ? "#1d5536" : "#a39d8c", width: 20 }}
                  >
                    {s.rank}
                  </span>
                  <div className="flex-1 min-w-0">
                    <div className="truncate" style={{ fontSize: 13.5 }}>
                      {s.event}
                      {s.mine && <span className="text-green ml-[7px]">★</span>}
                    </div>
                    <div className="font-mono mt-0.5" style={{ fontSize: 9.5, color: s.hot ? "#a8473a" : "#a39d8c" }}>
                      {s.hot && <span className="mr-[5px]">● </span>}
                      {s.league} · {s.time}
                    </div>
                  </div>
                  <span className="font-mono text-faint shrink-0" style={{ fontSize: 9.5 }}>{s.viewers}</span>
                  <span
                    className="ons-tap font-mono shrink-0"
                    style={{
                      fontSize: 9,
                      color: s.hot ? "#fff" : "#736e5f",
                      background: s.hot ? "#1d5536" : "transparent",
                      border: `1px solid ${s.hot ? "#1d5536" : "#e6e3dc"}`,
                      borderRadius: 999, padding: "4px 10px",
                    }}
                  >
                    WATCH
                  </span>
                </div>
              ))}
            </div>
          </Card>

          <Card>
            <K style={{ marginBottom: 10 }}>Sports News</K>
            <div className="flex gap-[11px] items-start">
              <span className="text-faint mt-px">
                <OnsIcon name="sports" size={16} stroke={1.5} />
              </span>
              <div>
                <div className="text-ink" style={{ fontSize: 13 }}>Not configured</div>
                <p className="text-faint m-0 mt-[3px]" style={{ fontSize: 11.5, lineHeight: 1.5 }}>
                  NEWS_API_KEY isn't set in .env — same dependency as Music. Expected, not a bug.
                </p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
