"use client";

import { useEffect, useState } from "react";
import { readingApi, type ReadingSummary } from "@/lib/api";
import {
  Card, PageHead, Stat, StatBand, K, Empty, Loading, ErrorState,
} from "@/components/ui/primitives";
import { Donut } from "@/components/ui/viz";

export default function ReadingPage() {
  const [data, setData] = useState<ReadingSummary | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    readingApi.summary().then(setData).catch((e) => setError(e.message));
  }, []);

  if (error) return <ErrorState message={error} />;
  if (!data) return <Loading />;

  const goal = 10;
  const booksRead = data.books_read ?? 0;
  const fiction = data.fiction_books ?? 0;
  const nonfiction = data.nonfiction_books ?? 0;

  // pace
  const now = new Date();
  const dayOfYear = Math.floor(
    (now.getTime() - new Date(now.getFullYear(), 0, 0).getTime()) / 86400000
  );
  const ytdTarget = Math.round((goal / 365) * dayOfYear);
  const behindBy = Math.max(0, ytdTarget - booksRead);

  return (
    <div className="ons-page" style={{ padding: "34px 44px 48px", maxWidth: 1380, margin: "0 auto" }}>
      <PageHead
        title="Reading"
        kicker="2026 · via Hardcover"
        right={
          <div className="font-mono text-right text-faint" style={{ fontSize: 9.5 }}>
            {booksRead} OF {goal} BOOKS<br />
            {behindBy > 0 ? `~${behindBy} BEHIND PACE` : "ON PACE"}
          </div>
        }
      />

      <StatBand>
        <Stat label="Books Read" value={booksRead} unit={`/ ${goal}`} accent />
        <Stat label="Fiction" value={fiction} />
        <Stat label="Nonfiction" value={nonfiction} />
        <Stat label="On-Pace Target" value={ytdTarget} unit="by now" last />
      </StatBand>

      <div className="grid gap-[22px] items-start" style={{ gridTemplateColumns: "1.4fr 1fr" }}>
        {/* Shelf */}
        <Card pad={0}>
          <div className="flex justify-between items-center" style={{ padding: "16px 18px 12px" }}>
            <K>2026 Shelf · finished</K>
            <span className="font-mono text-faint" style={{ fontSize: 9.5 }}>
              {booksRead} BOOKS
            </span>
          </div>
          <div style={{ padding: "0 18px 16px" }}>
            {booksRead === 0 ? (
              <Empty message="No finished books synced from Hardcover yet." />
            ) : (
              <Empty
                message={`${booksRead} books read — book-level details need a shelf endpoint.`}
                detail="The API returns counts only; individual titles require /reading/shelf."
              />
            )}
          </div>
        </Card>

        {/* Pace + split */}
        <div>
          <Card style={{ marginBottom: 22 }}>
            <div className="flex justify-between items-center mb-4">
              <K>Pace vs Goal · 2026</K>
              <span className="font-mono" style={{ fontSize: 9, color: behindBy > 0 ? "#a8473a" : "#1d5536" }}>
                {behindBy > 0 ? "BEHIND" : "ON TRACK"}
              </span>
            </div>
            <Empty
              message="Pace chart needs book-level rows with finish dates."
              detail="Will render when /reading/shelf exposes per-book data."
            />
            <div
              className="flex gap-4 font-mono border-t border-border-2 pt-3 mt-4"
              style={{ fontSize: 9.5 }}
            >
              <span className="text-green">● ACTUAL {booksRead}</span>
              <span className="text-faint">– – TARGET {ytdTarget}</span>
            </div>
          </Card>

          <Card>
            <K style={{ marginBottom: 16 }}>Fiction / Nonfiction</K>
            <div className="flex items-center gap-5">
              <Donut
                value={booksRead > 0 ? fiction / booksRead : 0}
                size={84}
                sw={11}
                color="#1d5536"
                track="#3a5f7a"
              >
                <div className="text-center">
                  <div className="font-serif text-[20px] font-bold">{booksRead}</div>
                  <div className="font-mono text-faint" style={{ fontSize: 7.5 }}>BOOKS</div>
                </div>
              </Donut>
              <div className="flex-1 flex flex-col gap-[10px]">
                <div className="flex items-center gap-[9px]">
                  <span className="rounded" style={{ width: 11, height: 11, background: "#1d5536" }} />
                  <span className="flex-1" style={{ fontSize: 13 }}>Fiction</span>
                  <span className="font-mono font-semibold" style={{ fontSize: 12 }}>{fiction}</span>
                </div>
                <div className="flex items-center gap-[9px]">
                  <span className="rounded" style={{ width: 11, height: 11, background: "#3a5f7a" }} />
                  <span className="flex-1" style={{ fontSize: 13 }}>Nonfiction</span>
                  <span className="font-mono font-semibold" style={{ fontSize: 12 }}>{nonfiction}</span>
                </div>
              </div>
            </div>
            <p className="text-faint italic mt-4 mb-0" style={{ fontSize: 11, lineHeight: 1.5 }}>
              In-progress books aren't tracked yet — Hardcover only syncs finished titles.
            </p>
          </Card>
        </div>
      </div>
    </div>
  );
}
