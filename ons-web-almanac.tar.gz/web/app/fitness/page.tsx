"use client";

import { useEffect, useState } from "react";
import { fitnessApi, type FitnessSummary } from "@/lib/api";
import {
  Card, PageHead, K, Empty, Loading, ErrorState,
} from "@/components/ui/primitives";
import { OnsIcon } from "@/components/ui/icons";
import { Sparkline } from "@/components/ui/viz";

// Training heatmap — combined run + crossfit day cells
function TrainingHeatmap({ weeklyRun, weeklyCf }: { weeklyRun: number[]; weeklyCf: number[] }) {
  const cols = 26, rows = 7, sz = 11, gap = 3;
  const RUN_RGB = "29,85,54";
  const CF_RGB = "154,106,30";

  const cells: Array<{ c: number; r: number; run: boolean; cfd: boolean; rInt: number; cInt: number }> = [];
  for (let c = 0; c < cols; c++) {
    const runW = weeklyRun[Math.floor((c / cols) * weeklyRun.length)] || 0;
    const cfW = weeklyCf[Math.floor((c / cols) * weeklyCf.length)] || 0;
    for (let r = 0; r < rows; r++) {
      const sR = Math.sin(c * 2.3 + r * 1.7) * 0.5 + 0.5;
      const sC = Math.sin(c * 1.1 + r * 2.9 + 5) * 0.5 + 0.5;
      const run = runW > 0 && sR > 0.66;
      const cfd = cfW > 0 && sC > 0.68;
      const rInt = run ? Math.min(1, (runW / 11) * (0.55 + sR * 0.6)) : 0;
      const cInt = cfd ? Math.min(1, (cfW / 4) * (0.55 + sC * 0.6)) : 0;
      cells.push({ c, r, run, cfd, rInt, cInt });
    }
  }

  const fill = (x: typeof cells[0]) => {
    if (x.run && x.cfd) return "#1d5536";
    if (x.run) return `rgba(${RUN_RGB},${(0.25 + x.rInt * 0.72).toFixed(2)})`;
    if (x.cfd) return `rgba(${CF_RGB},${(0.25 + x.cInt * 0.72).toFixed(2)})`;
    return "#efebe1";
  };

  return (
    <div>
      <svg width="100%" viewBox={`0 0 ${cols * (sz + gap)} ${rows * (sz + gap)}`} style={{ display: "block" }}>
        {cells.map((x, i) => {
          const both = x.run && x.cfd;
          return (
            <rect key={i} x={x.c * (sz + gap)} y={x.r * (sz + gap)} width={sz} height={sz} rx={2}
              fill={fill(x)} stroke={both ? "#9a6a1e" : "none"} strokeWidth={both ? 1.5 : 0} />
          );
        })}
      </svg>
      <div className="flex items-center gap-4 mt-[14px] font-mono text-muted" style={{ fontSize: 9 }}>
        <span className="flex items-center gap-[5px]">
          <span className="rounded-sm" style={{ width: 10, height: 10, background: `rgba(${RUN_RGB},0.8)` }} /> RUN
        </span>
        <span className="flex items-center gap-[5px]">
          <span className="rounded-sm" style={{ width: 10, height: 10, background: `rgba(${CF_RGB},0.8)` }} /> CROSSFIT
        </span>
        <span className="flex items-center gap-[5px]">
          <span className="rounded-sm" style={{ width: 10, height: 10, background: "#1d5536", border: "1.5px solid #9a6a1e", boxSizing: "border-box" }} /> BOTH
        </span>
        <span className="ml-auto text-faint">JAN → JUN</span>
      </div>
    </div>
  );
}

// Mini bar chart for weekly volume
function MiniVol({ data, color, h = 70 }: { data: number[]; color: string; h?: number }) {
  const max = Math.max(...data, 1);
  return (
    <div>
      <div className="flex items-end gap-[5px]" style={{ height: h }}>
        {data.map((v, i) => (
          <div key={i} className="flex-1 flex flex-col justify-end" style={{ height: "100%" }}>
            <div
              className="rounded-sm"
              style={{
                height: v > 0 ? `${Math.max(2, (v / max) * (h - 4))}px` : 0,
                background: v === 0 ? "#e6e3dc" : color,
              }}
            />
          </div>
        ))}
      </div>
      <div className="flex justify-between mt-1.5 font-mono text-faint" style={{ fontSize: 8 }}>
        <span>MAR</span><span>APR</span><span>MAY</span><span>JUN</span>
      </div>
    </div>
  );
}

function MiniStat({ v, u, l, color }: { v: string | number; u: string; l: string; color?: string }) {
  return (
    <div>
      <div className="font-serif font-bold leading-none" style={{ fontSize: 24, color: color ?? "#232a22" }}>
        {v}<span className="font-mono font-normal ml-0.5 text-faint" style={{ fontSize: 10 }}>{u}</span>
      </div>
      <div className="font-mono text-faint mt-[5px]" style={{ fontSize: 8.5, letterSpacing: "0.5px" }}>{l}</div>
    </div>
  );
}

export default function FitnessPage() {
  const [data, setData] = useState<FitnessSummary | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fitnessApi.summary().then(setData).catch((e) => setError(e.message));
  }, []);

  if (error) return <ErrorState message={error} />;
  if (!data) return <Loading />;

  const { running_summary: rs, recent_runs, weekly_miles } = data;
  const weeklyRunData = weekly_miles.map((w) => w.miles);

  // CrossFit placeholder data (SugarWOD not in API yet)
  const cfClassesYtd = 96;
  const cfWeekly = [2, 3, 1, 0, 2, 3, 2, 4, 3, 2, 3, 2];

  const paceSeries = [...recent_runs].reverse().map((r) => 12 - r.pace);

  return (
    <div className="ons-page ons-scroll" style={{ padding: "34px 44px 48px", maxWidth: 1380, margin: "0 auto" }}>
      <PageHead
        title="Fitness"
        kicker="Running + CrossFit · Strava + SugarWOD"
        right={
          <div className="font-mono text-right text-faint" style={{ fontSize: 9.5 }}>
            YTD 2026 · DENVER<br />{rs.total_runs} RUNS · {cfClassesYtd} CLASSES
          </div>
        }
      />

      {/* Training consistency heatmap */}
      <Card style={{ marginBottom: 26 }}>
        <div className="flex justify-between items-center mb-[18px]">
          <K>Training Consistency · 26 weeks</K>
          <span className="font-mono text-faint" style={{ fontSize: 9.5 }}>RUNS + CROSSFIT · JAN → JUN</span>
        </div>
        <TrainingHeatmap weeklyRun={weeklyRunData} weeklyCf={cfWeekly} />
      </Card>

      {/* Split: Running (left) / CrossFit (right) */}
      <div className="grid gap-[30px] items-start" style={{ gridTemplateColumns: "1fr 1fr" }}>
        {/* Running */}
        <div>
          <div className="flex justify-between items-center mb-4" style={{ borderTop: "2.5px solid #1d5536", paddingTop: 12 }}>
            <div className="flex items-center gap-[9px]">
              <span className="text-green"><OnsIcon name="fitness" size={18} stroke={1.8} /></span>
              <div>
                <div className="font-serif font-bold text-ink leading-none" style={{ fontSize: 19 }}>Running</div>
                <div className="font-mono text-faint mt-[3px]" style={{ fontSize: 8.5, letterSpacing: "1px" }}>STRAVA</div>
              </div>
            </div>
            <span className="font-mono text-faint" style={{ fontSize: 9 }}>↓ TRENDING FASTER</span>
          </div>

          <div className="grid grid-cols-3 gap-3 mb-5">
            <MiniStat v={rs.ytd_miles} u="mi" l="YTD MILES" color="#1d5536" />
            <MiniStat v={rs.avg_pace_min_mile} u="/mi" l="AVG PACE" />
            <MiniStat v={rs.total_runs} u="" l="TOTAL RUNS" />
          </div>

          <Card style={{ marginBottom: 22 }}>
            <K style={{ marginBottom: 14 }}>Pace Trend · last {recent_runs.length} runs</K>
            {paceSeries.length > 1 ? (
              <div className="text-green">
                <Sparkline data={paceSeries} w={420} h={82} stroke="#1d5536" sw={2.2} fill="#1d5536" dot />
              </div>
            ) : (
              <Empty message="Need more runs for a trend line." />
            )}
          </Card>

          <Card style={{ marginBottom: 22 }}>
            <div className="flex justify-between items-baseline mb-4">
              <K>Weekly Volume · {weeklyRunData.length} wk</K>
            </div>
            <MiniVol data={weeklyRunData} color="#1d5536" />
          </Card>

          <Card pad={0}>
            <div style={{ padding: "16px 18px 8px" }}><K>Recent Runs</K></div>
            <div style={{ padding: "0 18px 12px" }}>
              {recent_runs.length === 0 ? (
                <Empty message="No recent runs." />
              ) : (
                recent_runs.map((r, i) => (
                  <div key={i} className="ons-row flex items-center gap-3 border-t border-border-2" style={{ padding: "10px 6px", margin: "0 -6px" }}>
                    <span className="grid place-items-center shrink-0 text-green" style={{ width: 26, height: 26, borderRadius: 6, background: "#e9efe7" }}>
                      <OnsIcon name="fitness" size={15} stroke={1.7} />
                    </span>
                    <div className="flex-1">
                      <div style={{ fontSize: 13.5 }}>{r.miles.toFixed(2)} mi</div>
                      <div className="font-mono text-faint mt-px" style={{ fontSize: 10.5 }}>
                        {r.minutes.toFixed(0)} min · {r.pace.toFixed(1)}/mi
                      </div>
                    </div>
                    <span className="font-mono text-muted" style={{ fontSize: 10 }}>
                      {r.run_date.slice(5, 10)}
                    </span>
                  </div>
                ))
              )}
            </div>
          </Card>
        </div>

        {/* CrossFit */}
        <div>
          <div className="flex justify-between items-center mb-4" style={{ borderTop: "2.5px solid #9a6a1e", paddingTop: 12 }}>
            <div className="flex items-center gap-[9px]">
              <span style={{ color: "#9a6a1e" }}><OnsIcon name="habits" size={18} stroke={1.8} /></span>
              <div>
                <div className="font-serif font-bold text-ink leading-none" style={{ fontSize: 19 }}>CrossFit</div>
                <div className="font-mono text-faint mt-[3px]" style={{ fontSize: 8.5, letterSpacing: "1px" }}>SUGARWOD</div>
              </div>
            </div>
            <span className="font-mono text-faint" style={{ fontSize: 9 }}>{cfClassesYtd} CLASSES YTD</span>
          </div>

          <div className="grid grid-cols-3 gap-3 mb-5">
            <MiniStat v={cfClassesYtd} u="" l="CLASSES YTD" color="#9a6a1e" />
            <MiniStat v="2" u="" l="THIS WEEK" />
            <MiniStat v="9.6" u="hr" l="TRAINING" />
          </div>

          <Card accent accentColor="#9a6a1e" style={{ marginBottom: 22 }}>
            <div className="flex justify-between items-center mb-1.5">
              <K color="#9a6a1e">Current 1-Rep Maxes</K>
              <span className="font-mono text-faint" style={{ fontSize: 9 }}>TRAILING 9 MO</span>
            </div>
            <Empty
              message="CrossFit max data needs a /fitness/crossfit endpoint."
              detail="SugarWOD data isn't exposed via the API yet."
            />
          </Card>

          <Card style={{ marginBottom: 22 }}>
            <div className="flex justify-between items-baseline mb-4">
              <K>Weekly Classes · 12 wk</K>
            </div>
            <MiniVol data={cfWeekly} color="#9a6a1e" />
          </Card>

          <Card pad={0}>
            <div style={{ padding: "16px 18px 8px" }}><K>Recent WODs</K></div>
            <div style={{ padding: "0 18px 12px" }}>
              <Empty message="WOD history needs a /fitness/crossfit/recent endpoint." />
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
