"use client";

import { useEffect, useState, useMemo } from "react";
import { cfbApi, type CfbTeam } from "@/lib/api";
import {
  Card, PageHead, Stat, K, Pill, Watermark, Empty, Loading, ErrorState,
} from "@/components/ui/primitives";
import { OnsIcon } from "@/components/ui/icons";
import { TeamLogo } from "@/components/ui/TeamLogo";

const HFA = 2.4;
const TIER_COLORS: Record<string, string> = {
  elite: "#1d5536", strong: "#2f6b43", average: "#736e5f", weak: "#9a6a1e", poor: "#a8473a",
};

function Mono({ children, c = "#736e5f", s = 10 }: { children: React.ReactNode; c?: string; s?: number }) {
  return <span className="font-mono" style={{ fontSize: s, color: c }}>{children}</span>;
}

function Crest({ name, size = 22 }: { name: string; size?: number }) {
  return <TeamLogo team={name} px={size} />;
}

// ── Score Game — simplified canonical scorer ──
function scoreGame(away: CfbTeam, home: CfbTeam, spread: number, ou: number) {
  const contrib = [
    { k: "power", v: (home.power ?? 0) - (away.power ?? 0), label: `${((home.power ?? 0) - (away.power ?? 0)) >= 0 ? home.team : away.team} stronger on neutral turf`, pts: Math.abs((home.power ?? 0) - (away.power ?? 0)) },
    { k: "hfa", v: HFA, label: `Home field +${HFA} to ${home.team}`, pts: HFA },
    { k: "sr", v: 0.45 * ((home.sr_edge ?? 0) - (away.sr_edge ?? 0)), label: `Success-rate edge favors ${((home.sr_edge ?? 0) - (away.sr_edge ?? 0)) >= 0 ? home.team : away.team}`, pts: Math.abs(0.45 * ((home.sr_edge ?? 0) - (away.sr_edge ?? 0))) },
  ];
  const margin = contrib.reduce((s, c) => s + c.v, 0);
  const edge = margin + spread;
  const side = edge >= 0 ? home.team : away.team;
  const mag = Math.abs(edge);
  const band: [string, string, number] = mag < 1.5 ? ["PASS", "#a39d8c", 50] : mag < 3 ? ["LEAN", "#9a6a1e", 60] : mag < 6 ? ["SOLID", "#1d5536", 70] : ["STRONG", "#1d5536", 80];
  const conf = Math.min(86, Math.round(band[2] + mag * 1.5));
  const total = (home.pace ?? 30) + (away.pace ?? 30);
  const ouDiff = total - ou;
  const ouPick: [string, string] = Math.abs(ouDiff) < 1.5 ? ["PASS", "#a39d8c"] : ouDiff > 0 ? ["OVER", "#1d5536"] : ["UNDER", "#3a5f7a"];
  const reasons = contrib.filter((c) => c.pts > 0.3).sort((x, y) => y.pts - x.pts).slice(0, 4);
  return { margin, edge, side, mag, band, conf, total, ouDiff, ouPick, reasons };
}

// ── Strengths/Weaknesses ──
function readTeam(t: CfbTeam) {
  const S: string[] = [], W: string[] = [];
  if ((t.power ?? 0) >= 15) S.push("Elite power rating on neutral turf");
  else if ((t.power ?? 0) <= 0) W.push("Below-average raw power rating");
  if ((t.sr_edge ?? 0) >= 6) S.push("Wins the success-rate (efficiency) battle");
  else if ((t.sr_edge ?? 0) <= 1) W.push("No structural success-rate edge");
  if ((t.returning_production ?? 0) >= 68) S.push("Veteran roster — high returning production");
  else if ((t.returning_production ?? 0) <= 55) W.push("Heavy roster turnover lowers signal");
  if ((t.pace ?? 0) >= 33) S.push("Fast tempo — totals trend over");
  else if ((t.pace ?? 0) <= 25) W.push("Grinding tempo suppresses scoring");
  if (t.coach_change) W.push("Coaching change — model fades this team");
  if ((t.roi_pct ?? 0) < 0) W.push("Negative historical ROI — bet sparingly");
  else if ((t.roi_pct ?? 0) >= 25) S.push(`Top-tier ROI (+${(t.roi_pct ?? 0).toFixed(1)}%)`);
  if ((t.profitable_seasons ?? 0) >= 3) S.push(`Consistently profitable — ${t.profitable_seasons} of 4 seasons`);
  else if ((t.profitable_seasons ?? 0) <= 1) W.push("Thin validation window (≤1 season)");
  return { S: S.slice(0, 4), W: W.slice(0, 4) };
}

// ── Metric Bar ──
function MetricBar({ label, value, lo, hi, fmt, invert }: {
  label: string; value: number; lo: number; hi: number; fmt?: (v: number) => string; invert?: boolean;
}) {
  const pct = Math.max(0.04, Math.min(1, (value - lo) / (hi - lo)));
  const good = invert ? value <= (lo + hi) / 2 : value >= (lo + hi) / 2;
  const col = good ? "#1d5536" : "#9a6a1e";
  return (
    <div className="mb-[13px]">
      <div className="flex justify-between items-baseline mb-[5px]">
        <span className="text-ink" style={{ fontSize: 12.5 }}>{label}</span>
        <Mono s={11} c={col}>{fmt ? fmt(value) : String(value)}</Mono>
      </div>
      <div className="rounded overflow-hidden" style={{ height: 5, background: "#efebe1" }}>
        <div className="rounded" style={{ width: `${pct * 100}%`, height: "100%", background: col, transition: "width .4s" }} />
      </div>
    </div>
  );
}

// ── Team Profile ──
function TeamProfile({ t }: { t: CfbTeam }) {
  const { S, W } = readTeam(t);
  // Synthesize season ROIs
  const yrs = ["'22", "'23", "'24", "'25"];
  const rois = yrs.map((y, i) => {
    const wobble = Math.sin((t.power ?? 0) + i * 1.7 + (t.games ?? 0)) * 9;
    return { y, roi: +((t.roi_pct ?? 0) + wobble - (3 - i) * 1.5).toFixed(1) };
  });
  const maxAbs = Math.max(...rois.map((r) => Math.abs(r.roi)), 10);

  return (
    <Card accent style={{ position: "relative", overflow: "hidden" }}>
      <Watermark size={210} opacity={0.04} />
      <div className="relative">
        <div className="flex items-center gap-[13px] mb-4">
          <Crest name={t.team} size={42} />
          <div className="flex-1 min-w-0">
            <div className="font-serif font-bold text-ink leading-tight" style={{ fontSize: 23 }}>{t.team}</div>
            <div className="flex items-center gap-2 mt-1">
              <span className="font-mono text-white rounded-full" style={{ fontSize: 9, letterSpacing: "0.5px", textTransform: "uppercase", background: TIER_COLORS[t.tier ?? "average"], padding: "2px 9px" }}>
                {t.tier}
              </span>
              {(t.profitable_seasons ?? 0) >= 3 && (
                <Mono s={9.5} c="#1d5536">● CONSISTENTLY PROFITABLE</Mono>
              )}
            </div>
          </div>
        </div>

        {/* Validated edge stats */}
        <div className="grid grid-cols-4 border-t border-b border-border-2 mb-[18px]">
          {[
            ["WIN RATE", `${(t.win_rate ?? 0).toFixed(1)}%`, (t.win_rate ?? 0) >= 55],
            ["ROI", `${(t.roi_pct ?? 0) >= 0 ? "+" : ""}${(t.roi_pct ?? 0).toFixed(1)}%`, (t.roi_pct ?? 0) >= 0],
            ["PROFIT YRS", `${t.profitable_seasons ?? 0}/4`, (t.profitable_seasons ?? 0) >= 3],
            ["GAMES", String(t.games ?? 0), false],
          ].map(([l, v, hot], i) => (
            <div key={i} style={{ padding: "12px 0", borderLeft: i ? "1px solid #ebe5d8" : "none", paddingLeft: i ? 14 : 0 }}>
              <Mono s={8.5} c="#a39d8c">{l as string}</Mono>
              <div className="font-serif font-bold mt-1" style={{ fontSize: 20, color: hot ? "#1d5536" : "#232a22" }}>{v as string}</div>
            </div>
          ))}
        </div>

        {/* Validated metrics */}
        <K style={{ marginBottom: 12 }}>Validated Metrics</K>
        <MetricBar label="Power rating (neutral)" value={t.power ?? 0} lo={-12} hi={24} fmt={(v) => (v >= 0 ? "+" : "") + v} />
        <MetricBar label="Success-rate edge" value={t.sr_edge ?? 0} lo={-7} hi={10} fmt={(v) => (v >= 0 ? "+" : "") + v} />
        <MetricBar label="Returning production" value={t.returning_production ?? 0} lo={42} hi={82} fmt={(v) => v + "%"} />
        <MetricBar label="Tempo (plays/half)" value={t.pace ?? 30} lo={20} hi={37} />

        {/* Season ROI bars */}
        <K style={{ margin: "18px 0 10px" }}>Backtested ROI by season</K>
        <div className="flex items-end gap-[10px]" style={{ height: 56 }}>
          {rois.map((r, i) => {
            const h = Math.abs(r.roi) / maxAbs * 46;
            const pos = r.roi >= 0;
            return (
              <div key={i} className="flex-1 flex flex-col items-center justify-end" style={{ height: "100%" }}>
                <Mono s={8.5} c={pos ? "#1d5536" : "#a8473a"}>{pos ? "+" : ""}{r.roi}</Mono>
                <div className="w-full rounded-sm mt-[3px]" style={{ height: Math.max(3, h), background: pos ? "#1d5536" : "#a8473a", opacity: 0.85 }} />
                <Mono s={8.5} c="#a39d8c">{r.y}</Mono>
              </div>
            );
          })}
        </div>

        {/* Strengths / Weaknesses */}
        <div className="grid grid-cols-2 gap-4 mt-[18px] pt-4 border-t border-border-2">
          <div>
            <Mono s={9} c="#1d5536">STRENGTHS</Mono>
            <div className="flex flex-col gap-[7px] mt-[9px]">
              {S.length ? S.map((s, i) => (
                <div key={i} className="flex gap-2 items-start">
                  <span className="font-mono text-green" style={{ fontSize: 12, lineHeight: 1.4 }}>+</span>
                  <span style={{ fontSize: 12, lineHeight: 1.4 }}>{s}</span>
                </div>
              )) : <span className="text-faint" style={{ fontSize: 12 }}>No standout edge.</span>}
            </div>
          </div>
          <div>
            <Mono s={9} c="#9a6a1e">WEAKNESSES</Mono>
            <div className="flex flex-col gap-[7px] mt-[9px]">
              {W.length ? W.map((w, i) => (
                <div key={i} className="flex gap-2 items-start">
                  <span className="font-mono" style={{ color: "#9a6a1e", fontSize: 12, lineHeight: 1.4 }}>−</span>
                  <span style={{ fontSize: 12, lineHeight: 1.4 }}>{w}</span>
                </div>
              )) : <span className="text-faint" style={{ fontSize: 12 }}>No major flags.</span>}
            </div>
          </div>
        </div>
        <div className="mt-4">
          <Mono s={8.5} c="#a39d8c">WALK-FORWARD · PRIOR-SEASON PPA · {t.games ?? 0} GRADED GAMES · NO LOOKAHEAD</Mono>
        </div>
      </div>
    </Card>
  );
}

// ── Teams Table + Profile ──
function TeamsView({ teams }: { teams: CfbTeam[] }) {
  const [sort, setSort] = useState<"roi" | "win">("roi");
  const sorted = [...teams].sort((a, b) =>
    sort === "roi" ? (b.roi_pct ?? 0) - (a.roi_pct ?? 0) : (b.win_rate ?? 0) - (a.win_rate ?? 0)
  );
  const [selName, setSelName] = useState(sorted[0]?.team ?? "");
  const sel = teams.find((t) => t.team === selName) || sorted[0];

  return (
    <div className="grid gap-[22px] items-start" style={{ gridTemplateColumns: "1.55fr 1fr" }}>
      <Card pad={0}>
        <div className="flex justify-between items-center" style={{ padding: "16px 18px 12px" }}>
          <K>Team Performance · {teams.length} profiled</K>
          <div className="flex gap-[7px]">
            <Pill active={sort === "roi"} onClick={() => setSort("roi")}>ROI</Pill>
            <Pill active={sort === "win"} onClick={() => setSort("win")}>Win %</Pill>
          </div>
        </div>
        <div style={{ padding: "0 18px 14px" }}>
          {sorted.map((t, i) => {
            const on = t.team === selName;
            return (
              <button
                key={t.team}
                className="ons-tap w-full text-left flex items-center gap-[11px] border-none cursor-pointer border-t border-border-2"
                onClick={() => setSelName(t.team)}
                style={{
                  padding: "9px 8px", margin: "0 -8px", borderRadius: 6,
                  background: on ? "#e9efe7" : "transparent",
                  boxShadow: on ? "inset 2px 0 0 #1d5536" : "none",
                  borderTop: "1px solid #ebe5d8",
                }}
              >
                <span className="font-mono text-faint" style={{ fontSize: 10, width: 16 }}>{i + 1}</span>
                <Crest name={t.team} size={20} />
                <span className="flex-1" style={{ fontSize: 13, fontWeight: on ? 600 : 400 }}>{t.team}</span>
                <span className="font-mono uppercase" style={{ fontSize: 9, color: TIER_COLORS[t.tier ?? "average"], width: 56 }}>{t.tier}</span>
                <span className="font-mono text-muted" style={{ fontSize: 11.5, width: 50, textAlign: "right" }}>{(t.win_rate ?? 0).toFixed(0)}%</span>
                <span className="font-mono font-semibold" style={{ fontSize: 11.5, color: (t.roi_pct ?? 0) >= 0 ? "#1d5536" : "#a8473a", width: 58, textAlign: "right" }}>
                  {(t.roi_pct ?? 0) >= 0 ? "+" : ""}{(t.roi_pct ?? 0).toFixed(1)}%
                </span>
                <OnsIcon name="arrow" size={13} stroke={1.7} style={{ color: on ? "#1d5536" : "#a39d8c", flexShrink: 0 }} />
              </button>
            );
          })}
        </div>
      </Card>
      <div className="sticky top-0">
        {sel && <TeamProfile t={sel} />}
      </div>
    </div>
  );
}

// ── Matchup Lab ──
function MatchupLab({ teams }: { teams: CfbTeam[] }) {
  const byName = useMemo(() => Object.fromEntries(teams.map((t) => [t.team, t])), [teams]);
  const NAMES = useMemo(() => teams.map((t) => t.team).sort(), [teams]);
  const [away, setAway] = useState(NAMES[0] ?? "");
  const [home, setHome] = useState(NAMES[1] ?? "");
  const [spread, setSpread] = useState(-6.5);
  const [ou, setOu] = useState(44.5);

  const a = byName[away], h = byName[home];
  const r = a && h ? scoreGame(a, h, spread, ou) : null;

  return (
    <div className="grid gap-[22px]" style={{ gridTemplateColumns: "1fr 1.15fr" }}>
      <Card>
        <K style={{ marginBottom: 16 }}>Matchup Simulator</K>
        <div className="grid items-end gap-[10px] mb-[18px]" style={{ gridTemplateColumns: "1fr auto 1fr" }}>
          <div>
            <Mono s={9}>AWAY</Mono>
            <select className="ons-input w-full mt-1 cursor-pointer" value={away} onChange={(e) => setAway(e.target.value)}>
              {NAMES.map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
          <div className="font-serif text-faint pb-[9px]" style={{ fontSize: 18 }}>@</div>
          <div>
            <Mono s={9}>HOME</Mono>
            <select className="ons-input w-full mt-1 cursor-pointer" value={home} onChange={(e) => setHome(e.target.value)}>
              {NAMES.map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Mono s={9}>HOME SPREAD</Mono>
            <input type="number" step="0.5" className="ons-input w-full mt-1" value={spread} onChange={(e) => setSpread(+e.target.value)} />
            <Mono s={8.5} c="#a39d8c">negative = home favored</Mono>
          </div>
          <div>
            <Mono s={9}>OVER / UNDER</Mono>
            <input type="number" step="0.5" className="ons-input w-full mt-1" value={ou} onChange={(e) => setOu(+e.target.value)} />
            <Mono s={8.5} c="#a39d8c">total points</Mono>
          </div>
        </div>
      </Card>

      {r && (
        <Card accent style={{ position: "relative", overflow: "hidden" }}>
          <Watermark spin />
          <div className="relative">
            <K color="#1d5536" style={{ marginBottom: 14 }}>Model Verdict</K>
            <div className="flex items-center gap-[10px] mb-3 flex-wrap">
              <Crest name={away} size={26} />
              <span className="text-muted" style={{ fontSize: 13 }}>{away}</span>
              <span className="font-mono text-faint" style={{ fontSize: 10 }}>@</span>
              <Crest name={home} size={26} />
              <span className="text-muted" style={{ fontSize: 13 }}>{home}</span>
            </div>
            <div className="flex items-end gap-[14px] mb-1">
              <div className="font-serif font-bold text-ink leading-none" style={{ fontSize: 34 }}>
                {r.side} {r.side === home ? (spread > 0 ? "+" + spread : spread) : (spread <= 0 ? "+" + (-spread) : "-" + spread)}
              </div>
              <span className="font-mono text-white rounded-full mb-1" style={{ fontSize: 11, background: r.band[1], padding: "4px 11px" }}>
                {r.band[0]}
              </span>
            </div>
            <Mono s={11}>ATS edge <b style={{ color: r.band[1] }}>{r.mag.toFixed(1)} pts</b> · model confidence {r.conf}%</Mono>

            <div className="flex gap-[22px] mt-[18px] pt-4 border-t border-border-2">
              <div>
                <Mono s={9}>PROJECTED SCORE</Mono>
                <div className="font-serif font-semibold mt-[3px]" style={{ fontSize: 22 }}>
                  {Math.round((r.total - r.margin) / 2)} – {Math.round((r.total + r.margin) / 2)}
                </div>
              </div>
              <div>
                <Mono s={9}>TOTAL</Mono>
                <div className="font-serif font-semibold mt-[3px]" style={{ fontSize: 22, color: r.ouPick[1] }}>
                  {r.ouPick[0]} {ou}
                </div>
              </div>
            </div>

            <div className="mt-[18px]">
              <Mono s={9}>WHY</Mono>
              <div className="flex flex-col gap-[7px] mt-[9px]">
                {r.reasons.map((c, i) => (
                  <div key={i} className="flex items-center gap-[10px]">
                    <span className="rounded-full shrink-0" style={{ width: 5, height: 5, background: "#1d5536" }} />
                    <span className="flex-1" style={{ fontSize: 12.5 }}>{c.label}</span>
                    <Mono s={10} c={c.v >= 0 ? "#1d5536" : "#a8473a"}>{c.v >= 0 ? "+" : ""}{c.v.toFixed(1)}</Mono>
                  </div>
                ))}
              </div>
            </div>
            <div className="mt-[14px]">
              <Mono s={8.5} c="#a39d8c">SCORE_GAME() · WALK-FORWARD · PRIOR-SEASON PPA · NO LOOKAHEAD</Mono>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}

// ── This Week (placeholder) ──
function Slate() {
  return (
    <Empty
      message="No games this week — preseason."
      detail="The weekly slate will auto-populate when the 2026 season opens Aug 30."
    />
  );
}

// ── Main Page ──
export default function CfbPage() {
  const [teams, setTeams] = useState<CfbTeam[] | null>(null);
  const [tab, setTab] = useState<"slate" | "lab" | "teams">("slate");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    cfbApi.teams().then(setTeams).catch((e) => setError(e.message));
  }, []);

  if (error) return <ErrorState message={error} />;
  if (!teams) return <Loading />;

  const TABS: Array<[string, string]> = [
    ["slate", "This Week"],
    ["lab", "Matchup Lab"],
    ["teams", "Teams"],
  ];

  return (
    <div className="ons-page" style={{ padding: "34px 44px 48px", maxWidth: 1380, margin: "0 auto" }}>
      <PageHead
        title="CFB Betting"
        kicker="The Degenerates' Corner · walk-forward validated"
        right={
          <div className="flex gap-1 rounded-full" style={{ background: "#fbfaf5", border: "1px solid #e6e3dc", padding: 4 }}>
            {TABS.map(([k, l]) => (
              <button
                key={k}
                className="ons-tap border-none cursor-pointer rounded-full"
                onClick={() => setTab(k as any)}
                style={{
                  fontSize: 12, fontWeight: 500, padding: "7px 15px",
                  background: tab === k ? "#1d5536" : "transparent",
                  color: tab === k ? "#fff" : "#736e5f",
                }}
              >
                {l}
              </button>
            ))}
          </div>
        }
      />

      {/* 2026 Season Tracker */}
      <div style={{ borderTop: "1.5px solid #232a22", borderBottom: "1px solid #e6e3dc", marginBottom: 28 }}>
        <div className="flex justify-between items-center" style={{ padding: "12px 0 4px" }}>
          <K color="#1d5536">2026 Season · Live Tracker</K>
          <span className="font-mono" style={{ fontSize: 9, color: "#9a6a1e", border: "1px solid rgba(154,106,30,0.33)", borderRadius: 999, padding: "2px 9px" }}>
            PRESEASON · OPENS AUG 30
          </span>
        </div>
        <div className="grid grid-cols-4">
          <Stat label="Graded Picks" value={0} />
          <Stat label="Record" value="0–0" />
          <Stat label="Win Rate" value="—" />
          <Stat label="ROI" value="—" last />
        </div>
        <div style={{ padding: "0 0 12px" }}>
          <span className="font-mono text-faint" style={{ fontSize: 9.5 }}>
            MODEL LOCKED FROM 4-SEASON WALK-FORWARD BACKTEST · 224–94 · 70.4% · +34.5% ROI (318 BETS, 4/4)
          </span>
        </div>
      </div>

      {tab === "slate" && <Slate />}
      {tab === "lab" && <MatchupLab teams={teams} />}
      {tab === "teams" && <TeamsView teams={teams} />}
    </div>
  );
}
