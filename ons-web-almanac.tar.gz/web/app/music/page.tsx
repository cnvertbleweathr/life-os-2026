"use client";

import { useEffect, useState } from "react";
import { musicApi, type MusicSummary } from "@/lib/api";
import {
  Card, PageHead, Stat, StatBand, K, Empty, Loading, ErrorState,
} from "@/components/ui/primitives";
import { OnsIcon } from "@/components/ui/icons";

export default function MusicPage() {
  const [data, setData] = useState<MusicSummary | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    musicApi.summary().then(setData).catch((e) => setError(e.message));
  }, []);

  if (error) return <ErrorState message={error} />;
  if (!data) return <Loading />;

  const artists = data.top_artists ?? [];
  const topGenre = artists[0]?.name ?? "—";
  const hrs = data.listening_hours ?? 0;
  const streams = data.streams_ytd ?? 0;

  return (
    <div className="ons-page" style={{ padding: "34px 44px 48px", maxWidth: 1380, margin: "0 auto" }}>
      <PageHead
        title="Music"
        kicker="2026 · via Spotify"
        right={
          <div className="font-mono text-right text-faint" style={{ fontSize: 9.5 }}>
            {streams.toLocaleString()} STREAMS YTD<br />
            {artists.length} ARTISTS
          </div>
        }
      />

      <StatBand>
        <Stat label="Listening" value={hrs.toLocaleString()} unit="hrs" accent />
        <Stat label="Streams" value={streams.toLocaleString()} />
        <Stat label="Top Genre" value={topGenre} />
        <Stat label="Artists" value={artists.length} last />
      </StatBand>

      <div className="grid gap-[22px] items-start" style={{ gridTemplateColumns: "1.5fr 1fr" }}>
        {/* Top artists + tracks */}
        <div>
          <Card pad={0} style={{ marginBottom: 22 }}>
            <div style={{ padding: "16px 18px 12px" }}><K>Top Artists · YTD</K></div>
            <div style={{ padding: "0 18px 16px" }}>
              {artists.length === 0 ? (
                <Empty message="No streaming data yet — streams pipeline hasn't run." />
              ) : (
                artists.slice(0, 10).map((a: any, i: number) => {
                  const maxPlays = artists[0]?.plays ?? 1;
                  return (
                    <div
                      key={i}
                      className="flex items-center gap-[13px] border-t border-border-2"
                      style={{ padding: "11px 0" }}
                    >
                      <span
                        className="font-serif font-bold"
                        style={{ fontSize: 17, color: i === 0 ? "#1d5536" : "#a39d8c", width: 22 }}
                      >
                        {i + 1}
                      </span>
                      <div className="flex-1 min-w-0">
                        <div
                          className="truncate"
                          style={{ fontSize: 13.5, fontWeight: i === 0 ? 600 : 400 }}
                        >
                          {a.name}
                        </div>
                        <div className="rounded mt-1.5 overflow-hidden" style={{ height: 4, background: "#efebe1" }}>
                          <div
                            className="rounded"
                            style={{
                              width: `${((a.plays ?? 0) / maxPlays) * 100}%`,
                              height: "100%",
                              background: i === 0 ? "#1d5536" : "#2f6b43",
                            }}
                          />
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <div className="font-mono font-semibold" style={{ fontSize: 12 }}>{a.plays}</div>
                        <div className="font-mono text-faint" style={{ fontSize: 8.5 }}>
                          {a.hours ?? Math.round((a.minutes ?? 0) / 60)}h
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </Card>

          <Card pad={0}>
            <div style={{ padding: "16px 18px 12px" }}><K>Most-Played Tracks</K></div>
            <div style={{ padding: "0 18px 14px" }}>
              <Empty message="Track-level data needs the streams pipeline." />
            </div>
          </Card>
        </div>

        {/* Daily 10 */}
        <div>
          <Card accent pad={0} style={{ overflow: "hidden", marginBottom: 22 }}>
            <div
              style={{
                aspectRatio: "16/9",
                background: "repeating-linear-gradient(135deg, #efebe1, #efebe1 8px, #fbfaf5 8px, #fbfaf5 16px)",
                display: "grid",
                placeItems: "center",
                borderBottom: "1px solid #ebe5d8",
                position: "relative",
              }}
            >
              <div className="text-center p-4">
                <div className="font-mono text-green" style={{ fontSize: 9, letterSpacing: "1.5px" }}>
                  DAILY 10 · COVER
                </div>
                <div className="font-serif font-semibold text-ink mt-1.5" style={{ fontSize: 17 }}>
                  Today's Playlist
                </div>
              </div>
              <span
                className="absolute font-mono text-faint"
                style={{
                  top: 10, right: 12, fontSize: 8, letterSpacing: "0.5px",
                  border: "1px solid #e6e3dc", borderRadius: 999, padding: "2px 8px",
                }}
              >
                gpt-image-1
              </span>
            </div>
            <div style={{ padding: "14px 18px" }}>
              <Empty message="Daily 10 track list needs daily10_latest.json exposed via API." />
            </div>
          </Card>

          <Card>
            <K style={{ marginBottom: 10 }}>Music News</K>
            <div className="flex gap-[11px] items-start">
              <span className="text-faint mt-px">
                <OnsIcon name="music" size={16} stroke={1.5} />
              </span>
              <div>
                <div className="text-ink" style={{ fontSize: 13 }}>Not configured</div>
                <p className="text-faint m-0 mt-[3px]" style={{ fontSize: 11.5, lineHeight: 1.5 }}>
                  NEWS_API_KEY isn't set in .env — expected, not a bug. Set it to pull headlines here.
                </p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
